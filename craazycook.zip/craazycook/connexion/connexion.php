<?php
$pdo = new PDO ('mysql:host=localhost;dbname=craazycook', 'root', '', array(PDO::ATTR_ERRMODE => PDO :: ERRMODE_EXCEPTION, PDO:: MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8'));


?>
