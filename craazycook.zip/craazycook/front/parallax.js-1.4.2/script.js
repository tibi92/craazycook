console.log('ftghtryhjryh');

$('.parallax-window').parallax({imageSrc: 'front/img/ordi.jpg'});