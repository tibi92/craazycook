<?php require("../connexion/connexion.php"); ?>

<?php
//Mise a jour d'un gateau 


if(isset($_POST['gateau'])){

	$gateau = addslashes($_POST['gateau']);
	$date = addslashes($_POST['date']);
	$description = addslashes($_POST['description']);
	$id_gateau = addslashes($_GET['id_gateau']);

	$pdo -> exec("UPDATE gateau SET gateau='$gateau', dates='$date', description='$description' WHERE id_gateau='$id_gateau'");

		header('location:../admin/gateaux.php');//Le header pr revenir a la lste des experiences de l'utilisateur
		exit();

}
// Je récupère le gateau
$id_gateau = $_GET['id_gateau']; //par l'id_gateau et $_GET
$sql = $pdo -> query("SELECT * FROM gateau WHERE id_gateau = '$id_gateau'");
$ligne_gateau = $sql->fetch();
?>		
<!DOCTYPE html>
<html>
<head>
	<?php
	$sql = $pdo->query("SELECT * FROM utilisateur") ;
	$ligne = $sql->fetch();
?>
	<title ><?php echo 'Expériences | ' . $ligne['nom'].''.$ligne['prenom']; ?></title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body>
	<div id="contenu">
		<header>
			<?php require("../admin/admin_menu.php"); ?>
		</header>
		<h1> Les expériences | modification </h1>
		<div id="menu">
			<h2>Connexion : déconnexion</h2>
		</div>

		<div id="contenuPrincipal">
			<div>
					<form action="" method="POST">
					<label>Modification d'une formation</label>
						<input type="text" name="gateau" value="<?= $ligne_gateau['gateau']; ?>" required>
						<input type="text" name="dates" value="<?= $ligne_gateau['dates']; ?>" required>
						<input type="text" name="description" value="<?= $ligne_gateau['description']; ?>" required>
						<input type="submit" value="mettre à jour">
					</form>
			</div>
				
				<p> <?php echo $ligne_gateau['id_gateau']; ?>    </p>
		
		</div>

	</div>
</body>
</html>