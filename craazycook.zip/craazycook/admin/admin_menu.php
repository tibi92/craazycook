<?php require("../connexion/connexion.php"); ?>	

<header>
	<nav>
		<ul>
			<li><a href="utilisateur.php">Accueil</a></li>
			<li><a href="gateaux.php">Mes gateaux</a></li>
			
		
		</ul>
		<div class="clearfix"></div>
	</nav>
</header>